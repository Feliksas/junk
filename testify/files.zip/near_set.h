#pragma once

#include <vector>
#include <cstdint>

class NearSet {
 public:
    void Add(int64_t point) {
    }

    void Remove(int64_t point) {
    }

    // find all points x in set, such that abs(x - point) <= distance
    // returned vector must be sorted
    std::vector<int64_t> FindNear(int64_t point, int64_t distance) {
        return {};
    }

 private:
};
