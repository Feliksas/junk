#include "gtest/gtest.h"

#include <near_set.h>

TEST(NearSet, Simple) {
    ASSERT_EQ(1, 2);
}
